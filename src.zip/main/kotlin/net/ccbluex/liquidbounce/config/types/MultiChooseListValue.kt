package net.ccbluex.liquidbounce.config.types

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonPrimitive
import net.ccbluex.liquidbounce.config.gson.stategies.Exclude
import net.ccbluex.liquidbounce.config.gson.stategies.ProtocolExclude
import java.util.*

class MultiChooseEnumListValue<T>(
    name: String,
    value: EnumSet<T>,
    choices: EnumSet<T>,
    canBeNone: Boolean = true,
) : MultiChooseListValue<T>(
    name,
    value = value,
    choices = choices,
    canBeNone = canBeNone,
    listType = ListValueType.Enums,
    autoSorting = true
) where T : Enum<T>, T : NamedChoice {
    override val T.elementName: String
        get() = choiceName
}

class MultiChooseStringListValue(
    name: String,
    value: AbstractSet<String>,
    choices: AbstractSet<String>,
    canBeNone: Boolean = true,
) : MultiChooseListValue<String>(
    name,
    value = value,
    choices = choices,
    canBeNone = canBeNone,
    listType = ListValueType.String,
    autoSorting = false
)

sealed class MultiChooseListValue<T>(
    name: String,
    value: AbstractSet<T>,
    @Exclude val choices: AbstractSet<T>,

    /**
     * Can deselect all values or enable at least one
     */
    @Exclude val canBeNone: Boolean = true,
    listType: ListValueType,

    /**
     * If the [AbstractSet] automatically implements sorting and guarantees order,
     * then set the [autoSorting] to true.
     * Otherwise, if the insertion order is not guaranteed,
     * leave [autoSorting] to false and then the implementation guarantees the order.
     */
    @Exclude @ProtocolExclude private val autoSorting: Boolean
) : Value<AbstractSet<T>>(
    name,
    defaultValue = value,
    valueType = ValueType.MULTI_CHOOSE,
    listType = listType
) {
    init {
        if (!canBeNone) {
            require(choices.isNotEmpty()) {
                "There are no values provided, " +
                    "but at least one must be selected. (required because by canBeNone = false)"
            }

            require(value.isNotEmpty()) {
                "There are no default values enabled, " +
                    "but at least one must be selected. (required because by canBeNone = false)"
            }
        }

        val extra = HashSet(value)
        extra.removeAll(choices)

        require(extra.isEmpty()) {
            "Value contains extra elements not present in choices: $extra"
        }
    }

    override fun deserializeFrom(gson: Gson, element: JsonElement) {
        val active = get()
        active.clear()

        when (element) {
            is JsonArray -> element.forEach { active.tryToEnable(it.asString) }
            is JsonPrimitive -> active.tryToEnable(element.asString)
        }

        if (!canBeNone && active.isEmpty()) {
            active.addAll(choices)
        } else {
            active.sortIfAutoSortingDisabled()
        }

        set(active)
    }

    private fun MutableSet<T>.tryToEnable(name: String) {
        val choiceWithName = choices.firstOrNull { it.elementName == name }

        if (choiceWithName != null) {
            add(choiceWithName)
        }
    }

    fun toggle(value: T): Boolean {
        require(value in choices) {
            "Provided value is not in the choices: $value"
        }

        val current = get()

        val isActive = value in current

        if (isActive) {
            if (!canBeNone && current.size <= 1) {
                return true
            }

            current.remove(value)
        } else {
            current.add(value)
        }

        current.sortIfAutoSortingDisabled()
        set(current)

        return !isActive
    }

    private fun AbstractSet<T>.sortIfAutoSortingDisabled() {
        if (autoSorting) {
            return
        }

        val temp = LinkedHashSet(this)
        clear()

        for (choice in choices) {
            if (temp.contains(choice)) {
                add(choice)
            }
        }
    }

    protected open val T.elementName: String get() = this.toString()

    operator fun contains(choice: T) = get().contains(choice)
}
