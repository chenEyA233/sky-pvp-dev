package net.ccbluex.liquidbounce.interfaces;

public interface ClientPlayerEntityAddition {
    int liquid_bounce$getAirTicks();
    int liquid_bounce$getOnGroundTicks();
}
