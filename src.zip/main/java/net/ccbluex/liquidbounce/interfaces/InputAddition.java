package net.ccbluex.liquidbounce.interfaces;

import net.minecraft.util.PlayerInput;

public interface InputAddition {
    PlayerInput liquid_bounce$getInitial();
    PlayerInput liquid_bounce$getUntransformed();
}
