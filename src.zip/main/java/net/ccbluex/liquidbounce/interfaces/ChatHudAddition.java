package net.ccbluex.liquidbounce.interfaces;

public interface ChatHudAddition {
    int liquidbounce_getChatY();
}
