<img class="watermark" src="img/lb-logo.svg" alt="watermark">

<style>
    .watermark {
        position: absolute;
        bottom: 15px;
        right: 15px;
        width: 165px;
    }
</style>
